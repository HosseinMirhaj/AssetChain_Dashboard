export interface Asset {
  id: string;
  enName: string;
  faName: string;
  category: 'metals' | 'auto' | 'petro' | 'bank' | 'global' | 'real_estate' | 'commodities';
  price: number;
  change: number;
  flag: string;
  locationEn: string;
  locationFa: string;
  progress: number; // For sale progress bars
}

export interface PortfolioItem {
  assetId: string;
  shares: number;
  avgPrice: number;
}

export interface Transaction {
  id: string;
  type: 'deposit' | 'withdraw' | 'buy' | 'sell';
  asset: string;
  amount: string;
  date: string;
  status: 'completed' | 'pending';
}

export type Theme = 'dark' | 'light';
export type Language = 'en' | 'fa';
