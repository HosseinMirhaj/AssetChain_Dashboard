import React, { useState, useEffect } from 'react';
import { 
  Coins, 
  Wallet, 
  History, 
  MessageSquare, 
  LogOut, 
  LogIn, 
  Globe, 
  Sun, 
  Moon, 
  TrendingUp, 
  MapPin, 
  CheckCircle, 
  Clock, 
  ArrowUpRight, 
  ArrowDownRight, 
  Percent, 
  Copy, 
  Menu, 
  X, 
  Info,
  Check,
  User,
  ShieldCheck,
  Share2,
  DollarSign,
  Search
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Asset, PortfolioItem, Transaction, Theme, Language } from './types';
import { INITIAL_ASSETS, TRANSLATIONS } from './data';
import LandingPage from './components/LandingPage';
import YieldChart from './components/YieldChart';

export default function App() {
  // Theme & Language State
  const [theme, setTheme] = useState<Theme>('dark');
  const [lang, setLang] = useState<Language>('fa');

  // Authentication State
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(false); // Start logged out so the user can see the login/signup buttons initially
  const [currentUser, setCurrentUser] = useState({
    username: 'demo',
    email: 'demo@assetchain.app',
    usdtBalance: 15450.00,
  });

  // Navigation State
  const [currentTab, setCurrentTab] = useState<'home' | 'market' | 'portfolio' | 'wallet' | 'history' | 'support' | 'about' | 'contact'>('home');
  const [marketFilter, setMarketFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Modals & Panels State
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [authMode, setAuthMode] = useState<'signIn' | 'signUp'>('signIn');
  const [authUsername, setAuthUsername] = useState<string>('demo');
  const [authPassword, setAuthPassword] = useState<string>('1234');
  const [authError, setAuthError] = useState<string>('');

  const [isBuyModalOpen, setIsBuyModalOpen] = useState<boolean>(false);
  const [isSellModalOpen, setIsSellModalOpen] = useState<boolean>(false);
  const [selectedAsset, setSelectedAsset] = useState<Asset | null>(null);

  // Trade Inputs
  const [buyAmount, setBuyAmount] = useState<string>('');
  const [sellShares, setSellShares] = useState<string>('');

  // Notifications / Alert Feedbacks
  const [alertMessage, setAlertMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  // App Wallet Staking/Deposit State
  const [walletTab, setWalletTab] = useState<'deposit' | 'withdraw'>('deposit');
  const [depositNetwork, setDepositNetwork] = useState<'trc20' | 'erc20' | 'bep20'>('trc20');
  const [depositTxid, setDepositTxid] = useState<string>('');
  const [withdrawAddress, setWithdrawAddress] = useState<string>('');
  const [withdrawAmount, setWithdrawAmount] = useState<string>('');

  // Support State
  const [supportText, setSupportText] = useState<string>('');

  // User Portfolio Data (stored in state so it adapts when buying/selling)
  const [myPortfolio, setMyPortfolio] = useState<PortfolioItem[]>([
    { assetId: 'FOOLAD', shares: 12000, avgPrice: 0.080 },
    { assetId: 'JUMEIRAH', shares: 15, avgPrice: 245.00 },
    { assetId: 'GOLD', shares: 3, avgPrice: 1180.00 }
  ]);

  // Transaction History Data
  const [transactions, setTransactions] = useState<Transaction[]>([
    { id: 'TX-1049', type: 'deposit', asset: 'USDT (TRC20)', amount: '+5,000.00', date: '2026-07-02 18:40', status: 'completed' },
    { id: 'TX-1048', type: 'buy', asset: 'FOOLAD', amount: '-960.00', date: '2026-07-01 11:15', status: 'completed' },
    { id: 'TX-1047', type: 'sell', asset: 'AAPL', amount: '+927.50', date: '2026-06-28 09:30', status: 'completed' },
    { id: 'TX-1046', type: 'withdraw', asset: 'USDT (ERC20)', amount: '-150.00', date: '2026-06-25 14:22', status: 'pending' },
  ]);

  // UI state for Mobile Hamburger Menu
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState<boolean>(false);
  const [isDropdownOpen, setIsDropdownOpen] = useState<boolean>(false);
  const [copiedCode, setCopiedCode] = useState<boolean>(false);

  // Dynamic APY / TVL / Units Stats
  const [stats, setStats] = useState({
    tvl: 124580250,
    soldUnits: 12480,
  });

  const t = TRANSLATIONS[lang];

  // Auto Dismiss alerts
  useEffect(() => {
    if (alertMessage) {
      const timer = setTimeout(() => {
        setAlertMessage(null);
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [alertMessage]);

  // Apply layout theme body classes
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [theme]);

  // Helper for triggering alert notifications
  const triggerAlert = (type: 'success' | 'error', text: string) => {
    setAlertMessage({ type, text });
  };

  // Auth Functions
  const handleAuthSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (authMode === 'signIn') {
      if (authUsername.trim().toLowerCase() === 'demo' && authPassword === '1234') {
        setIsLoggedIn(true);
        setCurrentTab('portfolio');
        setIsAuthModalOpen(false);
        setAuthError('');
        triggerAlert('success', lang === 'fa' ? `خوش آمدید، ${currentUser.username}` : `Welcome back, ${currentUser.username}`);
      } else {
        setAuthError(t.loginError);
      }
    } else {
      // Sign Up simulation
      if (authUsername.trim() && authPassword.length >= 4) {
        setCurrentUser({
          username: authUsername,
          email: `${authUsername}@assetchain.app`,
          usdtBalance: 10000.00, // starting balance for new users
        });
        setIsLoggedIn(true);
        setCurrentTab('portfolio');
        setIsAuthModalOpen(false);
        setAuthError('');
        triggerAlert('success', lang === 'fa' ? 'حساب کاربری جدید با ۱,۰۰۰ تتر هدیه ساخته شد!' : 'New account created with 1,000 USDT gift!');
      } else {
        setAuthError(lang === 'fa' ? 'لطفاً نام کاربری و رمز عبور (حداقل ۴ کاراکتر) وارد کنید.' : 'Please enter username and password (min 4 chars).');
      }
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setIsDropdownOpen(false);
    setCurrentTab('market');
    triggerAlert('success', lang === 'fa' ? 'از حساب کاربری خود خارج شدید.' : 'Logged out successfully.');
  };

  // Buy Order Exec
  const handleBuySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAsset) return;
    const investAmount = parseFloat(buyAmount);

    if (isNaN(investAmount) || investAmount <= 0) {
      triggerAlert('error', t.enterAmount);
      return;
    }

    if (investAmount > currentUser.usdtBalance) {
      triggerAlert('error', t.insufficientBalance);
      return;
    }

    const pricePerToken = selectedAsset.price;
    const purchasedShares = Math.floor(investAmount / pricePerToken);

    if (purchasedShares === 0) {
      triggerAlert('error', lang === 'fa' ? 'مبلغ سرمایه‌گذاری برای خرید حتی یک سهم کافی نیست!' : 'Investment amount is too low for a single share!');
      return;
    }

    // Deduct Balance
    const cost = purchasedShares * pricePerToken;
    const fee = cost * 0.001;
    const totalDeduction = cost + fee;

    if (totalDeduction > currentUser.usdtBalance) {
      triggerAlert('error', t.insufficientBalance);
      return;
    }

    // Update User USDT Balance
    setCurrentUser(prev => ({
      ...prev,
      usdtBalance: parseFloat((prev.usdtBalance - totalDeduction).toFixed(2))
    }));

    // Update Portfolio
    setMyPortfolio(prev => {
      const existing = prev.find(item => item.assetId === selectedAsset.id);
      if (existing) {
        const totalShares = existing.shares + purchasedShares;
        const totalCost = (existing.shares * existing.avgPrice) + cost;
        const newAvg = parseFloat((totalCost / totalShares).toFixed(4));
        return prev.map(item => item.assetId === selectedAsset.id ? { ...item, shares: totalShares, avgPrice: newAvg } : item);
      } else {
        return [...prev, { assetId: selectedAsset.id, shares: purchasedShares, avgPrice: pricePerToken }];
      }
    });

    // Add Transaction
    const newTx: Transaction = {
      id: `TX-${Math.floor(1000 + Math.random() * 9000)}`,
      type: 'buy',
      asset: selectedAsset.id,
      amount: `-${totalDeduction.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USDT`,
      date: new Date().toISOString().replace('T', ' ').substring(0, 16),
      status: 'completed'
    };
    setTransactions([newTx, ...transactions]);

    // Update stats slightly to show dynamism
    setStats(prev => ({
      ...prev,
      soldUnits: prev.soldUnits + purchasedShares,
      tvl: prev.tvl + cost
    }));

    setIsBuyModalOpen(false);
    setBuyAmount('');
    triggerAlert('success', t.orderExecuted);
  };

  // Sell Order Exec
  const handleSellSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAsset) return;
    const sharesToSellVal = parseInt(sellShares);

    const ownedItem = myPortfolio.find(p => p.assetId === selectedAsset.id);
    const maxShares = ownedItem ? ownedItem.shares : 0;

    if (isNaN(sharesToSellVal) || sharesToSellVal <= 0) {
      triggerAlert('error', t.enterAmount);
      return;
    }

    if (sharesToSellVal > maxShares) {
      triggerAlert('error', t.insufficientShares);
      return;
    }

    const revenue = sharesToSellVal * selectedAsset.price;
    const fee = revenue * 0.001;
    const netRevenue = revenue - fee;

    // Update User Balance
    setCurrentUser(prev => ({
      ...prev,
      usdtBalance: parseFloat((prev.usdtBalance + netRevenue).toFixed(2))
    }));

    // Update Portfolio
    setMyPortfolio(prev => {
      return prev.map(item => {
        if (item.assetId === selectedAsset.id) {
          return { ...item, shares: item.shares - sharesToSellVal };
        }
        return item;
      }).filter(item => item.shares > 0);
    });

    // Add Transaction
    const newTx: Transaction = {
      id: `TX-${Math.floor(1000 + Math.random() * 9000)}`,
      type: 'sell',
      asset: selectedAsset.id,
      amount: `+${netRevenue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USDT`,
      date: new Date().toISOString().replace('T', ' ').substring(0, 16),
      status: 'completed'
    };
    setTransactions([newTx, ...transactions]);

    setIsSellModalOpen(false);
    setSellShares('');
    triggerAlert('success', t.orderExecuted);
  };

  // Submit Deposit Hash
  const handleDepositSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!depositTxid.trim()) {
      triggerAlert('error', lang === 'fa' ? 'لطفاً کد هش تراکنش را وارد کنید!' : 'Please enter the transaction hash!');
      return;
    }

    // Add dummy pending transaction
    const amountVal = parseFloat((100 + Math.random() * 9900).toFixed(2));
    const newTx: Transaction = {
      id: `TX-${Math.floor(1000 + Math.random() * 9000)}`,
      type: 'deposit',
      asset: `USDT (${depositNetwork.toUpperCase()})`,
      amount: `+${amountVal.toLocaleString()} USDT`,
      date: new Date().toISOString().replace('T', ' ').substring(0, 16),
      status: 'pending'
    };
    setTransactions([newTx, ...transactions]);
    setDepositTxid('');
    triggerAlert('success', t.depositSuccess);
  };

  // Submit Withdraw Request
  const handleWithdrawSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amountVal = parseFloat(withdrawAmount);

    if (!withdrawAddress.trim()) {
      triggerAlert('error', lang === 'fa' ? 'لطفاً آدرس مقصد را وارد کنید!' : 'Please enter destination address!');
      return;
    }

    if (isNaN(amountVal) || amountVal < 10) {
      triggerAlert('error', t.minAmount);
      return;
    }

    if (amountVal > currentUser.usdtBalance) {
      triggerAlert('error', t.insufficientBalance);
      return;
    }

    // Deduct user balance
    setCurrentUser(prev => ({
      ...prev,
      usdtBalance: parseFloat((prev.usdtBalance - amountVal).toFixed(2))
    }));

    // Add pending withdrawal to transaction history
    const newTx: Transaction = {
      id: `TX-${Math.floor(1000 + Math.random() * 9000)}`,
      type: 'withdraw',
      asset: `USDT (${depositNetwork.toUpperCase()})`,
      amount: `-${amountVal.toLocaleString()} USDT`,
      date: new Date().toISOString().replace('T', ' ').substring(0, 16),
      status: 'pending'
    };
    setTransactions([newTx, ...transactions]);
    setWithdrawAddress('');
    setWithdrawAmount('');
    triggerAlert('success', t.withdrawSuccess);
  };

  // Submit Support Ticket
  const handleSupportSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!supportText.trim()) return;

    const ticketNumber = Math.floor(1000 + Math.random() * 9000);
    const feedback = t.ticketSuccess.replace('{num}', `#TKT-${ticketNumber}`);
    triggerAlert('success', feedback);
    setSupportText('');
  };

  // Copy Referral Code
  const handleCopyCode = () => {
    navigator.clipboard.writeText('REF-ASSET-7729');
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  // Calculations for active modals
  const activeOwnedItem = selectedAsset ? myPortfolio.find(p => p.assetId === selectedAsset.id) : null;
  const activeMaxShares = activeOwnedItem ? activeOwnedItem.shares : 0;

  // Live total balance calculation: Free USDT + Value of all owned shares
  const totalSharesValue = myPortfolio.reduce((acc, curr) => {
    const asset = INITIAL_ASSETS.find(a => a.id === curr.assetId);
    return acc + (asset ? asset.price * curr.shares : 0);
  }, 0);
  const totalBalanceCalculated = currentUser.usdtBalance + totalSharesValue;

  // Live PnL calculation based on current prices and original average prices
  const totalPnLCalculated = myPortfolio.reduce((acc, curr) => {
    const asset = INITIAL_ASSETS.find(a => a.id === curr.assetId);
    return acc + (asset ? (asset.price - curr.avgPrice) * curr.shares : 0);
  }, 0);
  const totalPnLPctCalculated = totalPnLCalculated !== 0 ? (totalPnLCalculated / (totalBalanceCalculated - totalPnLCalculated)) * 100 : 0;

  // Filter & Search logic for marketplace
  const filteredAssets = INITIAL_ASSETS.filter(asset => {
    const matchesCategory = marketFilter === 'all' || asset.category === marketFilter;
    const searchString = searchQuery.trim().toLowerCase();
    const matchesSearch = !searchString || 
      asset.id.toLowerCase().includes(searchString) || 
      asset.enName.toLowerCase().includes(searchString) || 
      asset.faName.includes(searchString);
    return matchesCategory && matchesSearch;
  });

  return (
    <div className={`min-h-screen flex flex-col justify-between transition-colors duration-300 ${
      theme === 'dark' ? 'bg-[#020617] text-slate-100' : 'bg-slate-50 text-slate-900'
    }`} dir={lang === 'fa' ? 'rtl' : 'ltr'}>
      
      {/* Alert Banner / Notification Feed */}
      {alertMessage && (
        <div className={`fixed bottom-6 right-6 left-6 md:left-auto md:w-96 z-50 p-4 rounded-xl shadow-2xl flex items-center gap-3 animate-bounce border ${
          alertMessage.type === 'success' 
            ? 'bg-emerald-950/90 text-emerald-200 border-emerald-500/50' 
            : 'bg-rose-950/90 text-rose-200 border-rose-500/50'
        } backdrop-blur-md`}>
          <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
            alertMessage.type === 'success' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'
          }`}>
            {alertMessage.type === 'success' ? <CheckCircle size={20} /> : <Info size={20} />}
          </div>
          <div className="flex-1 text-sm font-medium">
            {alertMessage.text}
          </div>
          <button onClick={() => setAlertMessage(null)} className="text-slate-400 hover:text-white">
            <X size={16} />
          </button>
        </div>
      )}

      {/* Header / Navbar */}
      <nav className={`sticky top-0 z-40 px-4 md:px-8 h-16 flex items-center justify-between border-b transition-colors duration-300 ${
        theme === 'dark' ? 'border-slate-800/80 bg-slate-950/80' : 'border-slate-200 bg-white/90'
      } backdrop-blur-md`}>
        <div className="flex items-center gap-6 md:gap-8">
          {/* Logo */}
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => setCurrentTab(isLoggedIn ? 'portfolio' : 'home')}>
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center font-bold text-white shadow-lg shadow-blue-500/30">
              <Coins size={18} />
            </div>
            <span className={`text-xl font-extrabold tracking-tight ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
              {t.appName}
            </span>
          </div>

          {/* Desktop Nav Tabs */}
          <div className="hidden lg:flex items-center gap-6 text-sm font-semibold">
            {!isLoggedIn && (
              <button 
                onClick={() => setCurrentTab('home')}
                className={`pb-1 border-b-2 transition-all cursor-pointer ${
                  currentTab === 'home' 
                    ? 'border-blue-500 text-blue-500 font-extrabold' 
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                {t.home}
              </button>
            )}
            <button 
              onClick={() => setCurrentTab('market')}
              className={`pb-1 border-b-2 transition-all cursor-pointer ${
                currentTab === 'market' 
                  ? 'border-blue-500 text-blue-500 font-extrabold' 
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              {t.assetsMarket}
            </button>

            {isLoggedIn && (
              <>
                <button 
                  onClick={() => setCurrentTab('portfolio')}
                  className={`pb-1 border-b-2 transition-all cursor-pointer ${
                    currentTab === 'portfolio' 
                      ? 'border-blue-500 text-blue-500 font-extrabold' 
                      : 'border-transparent text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {t.portfolio}
                </button>
                <button 
                  onClick={() => setCurrentTab('wallet')}
                  className={`pb-1 border-b-2 transition-all cursor-pointer ${
                    currentTab === 'wallet' 
                      ? 'border-blue-500 text-blue-500 font-extrabold' 
                      : 'border-transparent text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {t.wallet}
                </button>
                <button 
                  onClick={() => setCurrentTab('history')}
                  className={`pb-1 border-b-2 transition-all cursor-pointer ${
                    currentTab === 'history' 
                      ? 'border-blue-500 text-blue-500 font-extrabold' 
                      : 'border-transparent text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {t.history}
                </button>
              </>
            )}

            <button 
              onClick={() => setCurrentTab('about')}
              className={`pb-1 border-b-2 transition-all cursor-pointer ${
                currentTab === 'about' 
                  ? 'border-blue-500 text-blue-500 font-extrabold' 
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              {t.aboutUs}
            </button>
            <button 
              onClick={() => setCurrentTab('contact')}
              className={`pb-1 border-b-2 transition-all cursor-pointer ${
                currentTab === 'contact' 
                  ? 'border-blue-500 text-blue-500 font-extrabold' 
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              {t.contactUs}
            </button>
          </div>
        </div>

        {/* Right Controls */}
        <div className="flex items-center gap-2 md:gap-3" dir="ltr">
          
          {/* Theme Switch */}
          <button 
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            className={`h-10 w-10 flex items-center justify-center rounded-xl border hover:opacity-80 transition-all cursor-pointer ${
              theme === 'dark' ? 'border-slate-800 bg-slate-900 text-slate-200' : 'border-slate-200 bg-slate-100 text-slate-700'
            }`}
            title={theme === 'dark' ? t.lightMode : t.darkMode}
          >
            {theme === 'dark' ? <Sun size={16} /> : <Moon size={16} />}
          </button>

          {/* Language Switch */}
          <button 
            onClick={() => setLang(lang === 'fa' ? 'en' : 'fa')}
            className={`h-10 px-4 text-xs font-black rounded-xl border hover:opacity-80 transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              theme === 'dark' ? 'border-slate-800 bg-slate-900 text-slate-200' : 'border-slate-200 bg-slate-100 text-slate-700'
            }`}
          >
            <Globe size={13} />
            <span>{lang === 'fa' ? 'EN' : 'FA'}</span>
          </button>

          {/* User Section / Login / Wallet Trigger */}
          {isLoggedIn ? (
            <div className="relative">
              <button 
                onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                className={`h-10 flex items-center justify-center gap-2 px-4 text-xs font-black rounded-xl border hover:opacity-90 transition-all cursor-pointer ${
                  theme === 'dark' ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-slate-100 border-slate-200 text-slate-800'
                }`}
              >
                <div className="w-5 h-5 rounded-full bg-blue-600 flex items-center justify-center text-white text-xs">
                  <User size={12} />
                </div>
                <span className="max-w-[80px] truncate">{currentUser.username}</span>
                <span className="text-[10px] opacity-60">▾</span>
              </button>

              {/* User Dropdown */}
              {isDropdownOpen && (
                <div className={`absolute right-0 mt-2 w-56 rounded-2xl border shadow-2xl z-50 overflow-hidden ${
                  theme === 'dark' ? 'bg-slate-900 border-slate-800 text-slate-200' : 'bg-white border-slate-200 text-slate-800'
                }`}>
                  <div className={`p-4 border-b ${theme === 'dark' ? 'border-slate-800' : 'border-slate-100'}`}>
                    <p className="text-xs opacity-60 truncate">{currentUser.email}</p>
                    <p className="text-sm font-bold mt-1 text-blue-500">
                      {currentUser.usdtBalance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USDT
                    </p>
                  </div>
                  <div className="p-2 space-y-1">
                    <button 
                      onClick={() => { setCurrentTab('portfolio'); setIsDropdownOpen(false); }}
                      className={`w-full text-start px-3 py-2.5 text-xs font-semibold rounded-xl transition-all hover:bg-blue-600/10 hover:text-blue-500 ${
                        currentTab === 'portfolio' ? 'bg-blue-600/10 text-blue-500' : ''
                      }`}
                    >
                      {t.myPortfolio}
                    </button>
                    <button 
                      onClick={() => { setCurrentTab('wallet'); setIsDropdownOpen(false); }}
                      className={`w-full text-start px-3 py-2.5 text-xs font-semibold rounded-xl transition-all hover:bg-blue-600/10 hover:text-blue-500 ${
                        currentTab === 'wallet' ? 'bg-blue-600/10 text-blue-500' : ''
                      }`}
                    >
                      {t.depositUsdt} / {t.withdrawUsdt}
                    </button>
                    <button 
                      onClick={() => { setCurrentTab('history'); setIsDropdownOpen(false); }}
                      className={`w-full text-start px-3 py-2.5 text-xs font-semibold rounded-xl transition-all hover:bg-blue-600/10 hover:text-blue-500 ${
                        currentTab === 'history' ? 'bg-blue-600/10 text-blue-500' : ''
                      }`}
                    >
                      {t.transactionHistory}
                    </button>
                    <button 
                      onClick={() => { setCurrentTab('support'); setIsDropdownOpen(false); }}
                      className={`w-full text-start px-3 py-2.5 text-xs font-semibold rounded-xl transition-all hover:bg-blue-600/10 hover:text-blue-500 ${
                        currentTab === 'support' ? 'bg-blue-600/10 text-blue-500' : ''
                      }`}
                    >
                      {t.supportCenter}
                    </button>
                    <button 
                      onClick={handleLogout}
                      className="w-full text-start px-3 py-2.5 text-xs font-bold text-rose-500 rounded-xl hover:bg-rose-500/10 transition-all"
                    >
                      {t.signOut}
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="hidden sm:flex items-center gap-2">
              <button 
                onClick={() => { setAuthMode('signIn'); setIsAuthModalOpen(true); }}
                className={`h-10 px-5 rounded-xl text-xs font-black transition-all border flex items-center justify-center cursor-pointer ${
                  theme === 'dark' 
                    ? 'border-slate-800 bg-slate-900/60 text-slate-300 hover:bg-slate-800' 
                    : 'border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100'
                }`}
              >
                {t.signIn}
              </button>
              <button 
                onClick={() => { setAuthMode('signUp'); setIsAuthModalOpen(true); }}
                className="h-10 px-5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-black transition-all shadow-lg shadow-blue-500/10 flex items-center justify-center cursor-pointer"
              >
                {t.signUp}
              </button>
            </div>
          )}

          {/* Mobile Menu Toggle */}
          <button 
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className={`p-2 rounded-xl border lg:hidden cursor-pointer z-50 ${
              theme === 'dark' ? 'border-slate-800 bg-slate-900 text-slate-200' : 'border-slate-200 bg-slate-100 text-slate-700'
            }`}
          >
            {isMobileMenuOpen ? <X size={18} /> : <Menu size={18} />}
          </button>
        </div>
      </nav>

      {/* Mobile Drawer */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <>
            {/* Backdrop Overlay */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMobileMenuOpen(false)}
              className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm z-50 lg:hidden"
            />

            {/* Sliding Drawer Panel */}
            <motion.div
              initial={{ x: lang === 'fa' ? '100%' : '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: lang === 'fa' ? '100%' : '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 220 }}
              className={`fixed top-0 bottom-0 ${
                lang === 'fa' ? 'right-0' : 'left-0'
              } w-full max-w-[320px] z-50 lg:hidden shadow-2xl flex flex-col justify-between transition-colors duration-300 ${
                theme === 'dark' 
                  ? 'bg-slate-950 border-slate-900 text-slate-100' 
                  : 'bg-white border-slate-200 text-slate-800'
              }`}
              dir={lang === 'fa' ? 'rtl' : 'ltr'}
            >
              <div className="flex flex-col flex-1 overflow-y-auto">
                {/* Header inside drawer */}
                <div className={`p-5 flex items-center justify-between border-b ${
                  theme === 'dark' ? 'border-slate-900/60' : 'border-slate-100'
                }`}>
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center font-bold text-white shadow-lg">
                      <Coins size={16} />
                    </div>
                    <span className="font-extrabold text-base tracking-tight">{t.appName}</span>
                  </div>
                  <button 
                    onClick={() => setIsMobileMenuOpen(false)}
                    className={`p-2 rounded-xl border cursor-pointer ${
                      theme === 'dark' ? 'border-slate-800 bg-slate-900' : 'border-slate-200 bg-slate-100'
                    }`}
                  >
                    <X size={16} />
                  </button>
                </div>

                {/* Profile / Auth section in drawer */}
                <div className={`p-5 ${
                  theme === 'dark' ? 'bg-slate-900/40 border-b border-slate-900/60' : 'bg-slate-50 border-b border-slate-100'
                }`}>
                  {isLoggedIn ? (
                    <div className="space-y-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold shadow-md shadow-blue-500/20">
                          <User size={18} />
                        </div>
                        <div className="min-w-0 flex-1">
                          <h4 className="font-bold text-sm truncate">{currentUser.username}</h4>
                          <p className="text-[10px] text-slate-400 truncate mt-0.5">{currentUser.email}</p>
                        </div>
                      </div>
                      
                      <div className={`p-3 rounded-2xl border ${
                        theme === 'dark' ? 'bg-slate-950 border-slate-800' : 'bg-white border-slate-200'
                      }`}>
                        <span className="text-[10px] text-slate-400 block font-semibold">{t.wallet}</span>
                        <div className="flex items-center justify-between mt-1">
                          <span className="text-sm font-extrabold text-blue-500">
                            {currentUser.usdtBalance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USDT
                          </span>
                          <button 
                            onClick={() => { setCurrentTab('wallet'); setIsMobileMenuOpen(false); }}
                            className="text-[10px] bg-blue-600 hover:bg-blue-500 text-white font-extrabold px-2 py-1 rounded-lg transition-all"
                          >
                            {lang === 'fa' ? 'واریز' : 'Deposit'}
                          </button>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      <p className="text-xs text-slate-400 font-bold leading-relaxed">
                        {lang === 'fa' ? 'به پلتفرم اسِت‌چین خوش آمدید! برای شروع معامله و دسترسی به کیف پول خود وارد شوید.' : 'Welcome to AssetChain! Log in to begin trading physical assets.'}
                      </p>
                      <div className="grid grid-cols-2 gap-2">
                        <button 
                          onClick={() => { setAuthMode('signIn'); setIsAuthModalOpen(true); setIsMobileMenuOpen(false); }}
                          className={`py-2.5 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                            theme === 'dark' 
                              ? 'border-slate-800 bg-slate-900 text-slate-200' 
                              : 'border-slate-200 bg-white text-slate-700'
                          }`}
                        >
                          {t.signIn}
                        </button>
                        <button 
                          onClick={() => { setAuthMode('signUp'); setIsAuthModalOpen(true); setIsMobileMenuOpen(false); }}
                          className="py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-blue-500/10 cursor-pointer"
                        >
                          {t.signUp}
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                {/* Main Navigation Links */}
                <div className="p-4 space-y-1">
                  {[
                    ...(!isLoggedIn ? [{ tab: 'home', label: t.home, icon: <Coins size={16} /> }] : []),
                    { tab: 'market', label: t.assetsMarket, icon: <TrendingUp size={16} /> },
                    ...(isLoggedIn ? [
                      { tab: 'portfolio', label: t.portfolio, icon: <ShieldCheck size={16} /> },
                      { tab: 'wallet', label: t.wallet, icon: <Wallet size={16} /> },
                      { tab: 'history', label: t.history, icon: <History size={16} /> },
                    ] : []),
                    { tab: 'about', label: t.aboutUs, icon: <Info size={16} /> },
                    { tab: 'contact', label: t.contactUs, icon: <MessageSquare size={16} /> },
                  ].map(item => {
                    const isActive = currentTab === item.tab;
                    return (
                      <button
                        key={item.tab}
                        onClick={() => { setCurrentTab(item.tab as any); setIsMobileMenuOpen(false); }}
                        className={`w-full flex items-center gap-3.5 px-4 py-3 rounded-2xl text-xs font-bold transition-all border cursor-pointer ${
                          isActive 
                            ? 'bg-blue-600/10 border-blue-500/30 text-blue-500' 
                            : theme === 'dark' 
                              ? 'bg-transparent border-transparent text-slate-300 hover:bg-slate-900' 
                              : 'bg-transparent border-transparent text-slate-600 hover:bg-slate-100'
                        }`}
                      >
                        <span className={isActive ? 'text-blue-500' : 'text-slate-400'}>{item.icon}</span>
                        <span>{item.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Bottom bar inside drawer */}
              <div className={`p-4 border-t space-y-4 ${
                theme === 'dark' ? 'border-slate-900 bg-slate-950' : 'border-slate-100 bg-slate-50'
              }`}>
                {/* Language / Theme Row */}
                <div className="grid grid-cols-2 gap-2">
                  {/* Theme Switcher inside drawer */}
                  <button 
                    onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                    className={`flex items-center justify-center gap-2 py-2 text-xs font-bold rounded-xl border transition-all cursor-pointer ${
                      theme === 'dark' ? 'border-slate-800 bg-slate-900 text-slate-200' : 'border-slate-200 bg-white text-slate-700'
                    }`}
                  >
                    {theme === 'dark' ? <Sun size={14} /> : <Moon size={14} />}
                    <span>{theme === 'dark' ? t.lightMode : t.darkMode}</span>
                  </button>

                  {/* Language Switcher inside drawer */}
                  <button 
                    onClick={() => setLang(lang === 'fa' ? 'en' : 'fa')}
                    className={`flex items-center justify-center gap-2 py-2 text-xs font-bold rounded-xl border transition-all cursor-pointer ${
                      theme === 'dark' ? 'border-slate-800 bg-slate-900 text-slate-200' : 'border-slate-200 bg-white text-slate-700'
                    }`}
                  >
                    <Globe size={13} />
                    <span>{lang === 'fa' ? 'English' : 'فارسی'}</span>
                  </button>
                </div>

                {isLoggedIn && (
                  <button 
                    onClick={() => { handleLogout(); setIsMobileMenuOpen(false); }}
                    className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl border border-rose-500/15 bg-rose-500/10 text-rose-500 font-bold text-xs hover:bg-rose-500/20 transition-all cursor-pointer"
                  >
                    <LogOut size={14} />
                    <span>{t.signOut}</span>
                  </button>
                )}

                <div className="flex justify-between items-center px-1 text-[10px] font-bold text-slate-400">
                  <span>{t.statusConnected}</span>
                  <span className="flex items-center gap-1.5">
                    <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
                    <span className="text-[10px] text-emerald-500">{lang === 'fa' ? 'برخط' : 'Live'}</span>
                  </span>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* YieldChart and Top Stats Banner Conditional Swap */}
      {currentTab !== 'home' && currentTab === 'market' && (
        <div className="w-full">
          {/* 1. Marketplace Header & Search with glassmorphism and ambient glow in full-width at the very top of the page */}
          <div className="max-w-7xl mx-auto px-4 md:px-8 pt-6">
            <div 
              className={`flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-3xl border transition-all duration-300 relative overflow-hidden backdrop-blur-md shadow-sm ${
                theme === 'dark' 
                  ? 'bg-slate-900/40 border-slate-800/80 hover:border-slate-700/80' 
                  : 'bg-white border-slate-200 hover:border-slate-300'
              }`}
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 rounded-full blur-2xl pointer-events-none"></div>
              <div className="relative z-10">
                <h1 className="text-xl font-extrabold tracking-tight">{t.topInvestment}</h1>
                <p className="text-slate-400 text-xs mt-1">{t.tagline}</p>
              </div>
              
              {/* Premium, Interactive Search Bar */}
              <div className="relative w-full md:w-80 group z-10" dir={lang === 'fa' ? 'rtl' : 'ltr'}>
                <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl opacity-0 group-focus-within:opacity-20 blur-md transition-all duration-300 pointer-events-none"></div>
                <div className={`relative flex items-center h-11 rounded-xl border px-3 transition-all duration-300 ${
                  theme === 'dark' 
                    ? 'bg-slate-950/80 border-slate-800 group-focus-within:border-blue-500' 
                    : 'bg-white border-slate-200 group-focus-within:border-blue-500 shadow-sm'
                }`}>
                  <Search className="text-slate-400 transition-colors group-focus-within:text-blue-500 flex-shrink-0" size={18} />
                  <input 
                    type="text" 
                    placeholder={lang === 'fa' ? 'جستجوی هوشمند دارایی...' : 'Smart search assets...'}
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className={`w-full bg-transparent border-none outline-none py-2 px-3 text-sm focus:ring-0 focus:outline-none placeholder-slate-400/80 ${
                      theme === 'dark' ? 'text-white' : 'text-slate-900'
                    }`}
                  />
                  {searchQuery ? (
                    <button 
                      onClick={() => setSearchQuery('')}
                      className="p-1 rounded-lg text-slate-400 hover:text-red-500 hover:bg-red-500/10 transition-all cursor-pointer"
                    >
                      <X size={16} />
                    </button>
                  ) : (
                    <div className={`hidden sm:flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-mono border ${
                      theme === 'dark' ? 'bg-slate-900 border-slate-800 text-slate-400' : 'bg-slate-100 border-slate-200 text-slate-500'
                    }`}>
                      <span>Ctrl</span>
                      <span>+</span>
                      <span>K</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* 2. YieldChart Price Graph directly below the search header */}
          <div className="max-w-7xl mx-auto px-4 md:px-8 pt-6">
            <YieldChart theme={theme} lang={lang} />
          </div>

          {/* 3. Top Stats Banner directly below the YieldChart */}
          <div className={`px-4 md:px-8 py-6 border-b border-t transition-colors duration-300 mt-6 ${
            theme === 'dark' ? 'bg-slate-950/40 border-slate-900' : 'bg-slate-100 border-slate-200'
          }`}>
            <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className={`p-5 rounded-2xl border shadow-sm transition-all hover:scale-[1.01] ${
                theme === 'dark' ? 'bg-slate-900/60 border-slate-800/80' : 'bg-white border-slate-200'
              }`}>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-slate-400 text-xs font-semibold">{t.statTvl}</span>
                  <TrendingUp size={16} className="text-emerald-500" />
                </div>
                <p className={`text-2xl md:text-3xl font-extrabold ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
                  ${stats.tvl.toLocaleString()}
                </p>
                <span className="text-emerald-500 text-xs font-bold mt-1 inline-block">
                  +14.2% {lang === 'fa' ? 'نسبت به ماه قبل' : 'vs last month'}
                </span>
              </div>

              <div className={`p-5 rounded-2xl border shadow-sm transition-all hover:scale-[1.01] ${
                theme === 'dark' ? 'bg-slate-900/60 border-slate-800/80' : 'bg-white border-slate-200'
              }`}>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-slate-400 text-xs font-semibold">{t.statApy}</span>
                  <Percent size={16} className="text-blue-500" />
                </div>
                <p className={`text-2xl md:text-3xl font-extrabold ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
                  16.45%
                </p>
                <span className="text-blue-500 text-xs font-bold mt-1 inline-block italic">
                  {lang === 'fa' ? 'تضمین شده با دارایی‌های فیزیکی واقعی' : 'Backed by real physical reserves'}
                </span>
              </div>

              <div className={`p-5 rounded-2xl border shadow-sm transition-all hover:scale-[1.01] ${
                theme === 'dark' ? 'bg-slate-900/60 border-slate-800/80' : 'bg-white border-slate-200'
              }`}>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-slate-400 text-xs font-semibold">{t.statSold}</span>
                  <ShieldCheck size={16} className="text-purple-500" />
                </div>
                <p className={`text-2xl md:text-3xl font-extrabold ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
                  {stats.soldUnits.toLocaleString()} <span className="text-sm font-normal text-slate-500">{lang === 'fa' ? 'توکن' : 'Tokens'}</span>
                </p>
                <span className="text-purple-500 text-xs font-bold mt-1 inline-block">
                  {lang === 'fa' ? 'در ۱۵ طبقه دارایی معتبر' : 'Across 15 certified asset classes'}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Standard Top Stats Banner for other tabs (not home or market) */}
      {currentTab !== 'home' && currentTab !== 'market' && (
        <div className={`px-4 md:px-8 py-6 border-b transition-colors duration-300 ${
          theme === 'dark' ? 'bg-slate-950/40 border-slate-900' : 'bg-slate-100 border-slate-200'
        }`}>
          <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className={`p-5 rounded-2xl border shadow-sm transition-all hover:scale-[1.01] ${
              theme === 'dark' ? 'bg-slate-900/60 border-slate-800/80' : 'bg-white border-slate-200'
            }`}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-slate-400 text-xs font-semibold">{t.statTvl}</span>
                <TrendingUp size={16} className="text-emerald-500" />
              </div>
              <p className={`text-2xl md:text-3xl font-extrabold ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
                ${stats.tvl.toLocaleString()}
              </p>
              <span className="text-emerald-500 text-xs font-bold mt-1 inline-block">
                +14.2% {lang === 'fa' ? 'نسبت به ماه قبل' : 'vs last month'}
              </span>
            </div>

            <div className={`p-5 rounded-2xl border shadow-sm transition-all hover:scale-[1.01] ${
              theme === 'dark' ? 'bg-slate-900/60 border-slate-800/80' : 'bg-white border-slate-200'
            }`}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-slate-400 text-xs font-semibold">{t.statApy}</span>
                <Percent size={16} className="text-blue-500" />
              </div>
              <p className={`text-2xl md:text-3xl font-extrabold ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
                16.45%
              </p>
              <span className="text-blue-500 text-xs font-bold mt-1 inline-block italic">
                {lang === 'fa' ? 'تضمین شده با دارایی‌های فیزیکی واقعی' : 'Backed by real physical reserves'}
              </span>
            </div>

            <div className={`p-5 rounded-2xl border shadow-sm transition-all hover:scale-[1.01] ${
              theme === 'dark' ? 'bg-slate-900/60 border-slate-800/80' : 'bg-white border-slate-200'
            }`}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-slate-400 text-xs font-semibold">{t.statSold}</span>
                <ShieldCheck size={16} className="text-purple-500" />
              </div>
              <p className={`text-2xl md:text-3xl font-extrabold ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
                {stats.soldUnits.toLocaleString()} <span className="text-sm font-normal text-slate-500">{lang === 'fa' ? 'توکن' : 'Tokens'}</span>
              </p>
              <span className="text-purple-500 text-xs font-bold mt-1 inline-block">
                {lang === 'fa' ? 'در ۱۵ طبقه دارایی معتبر' : 'Across 15 certified asset classes'}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Main Content Area - Split into Grid on Large Screens to feel premium */}
      <div className={`${currentTab === 'home' ? 'w-full' : 'max-w-7xl mx-auto px-4 md:px-8'} py-8 w-full flex-1`}>
        {currentTab === 'home' ? (
          <LandingPage 
            theme={theme}
            lang={lang}
            t={t}
            stats={stats}
            isLoggedIn={isLoggedIn}
            onLoginClick={() => { setAuthMode('signIn'); setIsAuthModalOpen(true); }}
            myPortfolio={myPortfolio}
            onExplore={(category?: string) => {
              setCurrentTab('market');
              if (category) {
                setMarketFilter(category);
              }
            }}
            onSupport={() => {
              if (!isLoggedIn) {
                setIsAuthModalOpen(true);
              } else {
                setCurrentTab('support');
              }
            }}
          />
        ) : (
          <div className="space-y-8">
            {/* YieldChart has been hoisted above the stats banner, so we don't render it here anymore */}

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* Left Column (Primary Views) */}
            <div className="lg:col-span-8 space-y-8">
              
              {/* View 1: Marketplace / Asset Listings */}
              {currentTab === 'market' && (
                <section className="space-y-6">

                {/* Filter Tags */}
                <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-none">
                  {['all', 'metals', 'auto', 'petro', 'bank', 'real_estate', 'commodities', 'global'].map(cat => (
                    <button
                      key={cat}
                      onClick={() => setMarketFilter(cat)}
                      className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                        marketFilter === cat
                          ? 'bg-blue-600 text-white shadow-md'
                          : theme === 'dark'
                            ? 'bg-slate-900 border border-slate-800 text-slate-300 hover:bg-slate-800'
                            : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      {cat === 'all' && t.allMarkets}
                      {cat === 'metals' && t.categoryMetals}
                      {cat === 'auto' && t.categoryAuto}
                      {cat === 'petro' && t.categoryPetro}
                      {cat === 'bank' && t.categoryBank}
                      {cat === 'real_estate' && t.categoryRealEstate}
                      {cat === 'commodities' && t.categoryCommodities}
                      {cat === 'global' && t.categoryGlobal}
                    </button>
                  ))}
                </div>

                {/* Asset Grid */}
                {filteredAssets.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {filteredAssets.map(asset => (
                      <div 
                        key={asset.id} 
                        className={`group rounded-3xl overflow-hidden border shadow-sm flex flex-col justify-between transition-all duration-300 hover:scale-[1.02] ${
                          theme === 'dark' 
                            ? 'bg-slate-900/60 border-slate-800 hover:border-slate-700 hover:shadow-blue-900/10' 
                            : 'bg-white border-slate-200 hover:border-slate-300 hover:shadow-slate-300/40'
                        }`}
                      >
                        {/* Card Cover with Gradient/Flag */}
                        <div className={`p-5 relative overflow-hidden h-36 flex flex-col justify-between ${
                          theme === 'dark' ? 'bg-slate-950/40' : 'bg-slate-100/60'
                        }`}>
                          {/* Ambient glow decoration */}
                          <div className="absolute -top-12 -right-12 w-24 h-24 rounded-full bg-blue-500/10 blur-xl"></div>
                          
                          <div className="flex items-center justify-between z-10">
                            {/* Location Badge */}
                            <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider ${
                              theme === 'dark' ? 'bg-slate-800 text-slate-300' : 'bg-white text-slate-600 border'
                            }`}>
                              <img 
                                src={`https://flagcdn.com/16x12/${asset.flag}.png`} 
                                alt={asset.flag}
                                className="rounded-[2px] shadow-sm"
                                referrerPolicy="no-referrer"
                              />
                              <span>{lang === 'fa' ? asset.locationFa : asset.locationEn}</span>
                            </div>

                            {/* ID badge */}
                            <span className="text-xs font-mono font-bold text-slate-400">
                              #{asset.id}
                            </span>
                          </div>

                          <div className="z-10">
                            <h3 className={`text-lg font-bold tracking-tight ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
                              {lang === 'fa' ? asset.faName : asset.enName}
                            </h3>
                            <p className="text-[10px] text-slate-400 mt-0.5">
                              {lang === 'fa' ? 'پشتوانه توزیع‌شده با تضمین فیزیکی' : 'Fully audited physical RWA contract'}
                            </p>
                          </div>
                        </div>

                        {/* Card Info Body */}
                        <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <p className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">{t.tokenPrice}</p>
                              <p className={`text-xl font-extrabold mt-0.5 ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
                                {asset.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 4 })} <span className="text-xs font-semibold text-blue-500">USDT</span>
                              </p>
                            </div>
                            <div>
                              <p className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold text-end">{t.expectedYield}</p>
                              <p className={`text-lg font-extrabold mt-0.5 text-end flex items-center justify-end gap-1 ${
                                asset.change >= 0 ? 'text-emerald-500' : 'text-rose-500'
                              }`}>
                                {asset.change >= 0 ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
                                <span>{asset.change >= 0 ? '+' : ''}{asset.change}%</span>
                              </p>
                            </div>
                          </div>

                          {/* Progress Line */}
                          <div className="space-y-1">
                            <div className="flex justify-between text-xs font-medium">
                              <span className="text-slate-400">{t.saleProgress}</span>
                              <span className={theme === 'dark' ? 'text-white' : 'text-slate-900'}>{asset.progress}%</span>
                            </div>
                            <div className={`h-1.5 rounded-full overflow-hidden ${theme === 'dark' ? 'bg-slate-800' : 'bg-slate-100'}`}>
                              <div 
                                className={`h-full rounded-full bg-blue-500 transition-all duration-1000`}
                                style={{ width: `${asset.progress}%` }}
                              ></div>
                            </div>
                          </div>

                          {/* Order Trigger */}
                          <div className="pt-2">
                            <button 
                              onClick={() => {
                                if (!isLoggedIn) {
                                  setIsAuthModalOpen(true);
                                } else {
                                  setSelectedAsset(asset);
                                  setBuyAmount('');
                                  setIsBuyModalOpen(true);
                                }
                              }}
                              className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-extrabold transition-all duration-200 cursor-pointer text-center"
                            >
                              {t.buyNow}
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className={`p-12 text-center rounded-2xl border ${
                    theme === 'dark' ? 'bg-slate-900/40 border-slate-800' : 'bg-slate-100 border-slate-200'
                  }`}>
                    <p className="text-slate-400 text-sm">{lang === 'fa' ? 'هیچ دارایی پیدا نشد.' : 'No assets found matching your criteria.'}</p>
                  </div>
                )}
              </section>
            )}

            {/* View 2: My Portfolio Details */}
            {currentTab === 'portfolio' && (
              <section className="space-y-6">
                <div>
                  <h1 className="text-2xl font-extrabold tracking-tight">{t.myPortfolio}</h1>
                  <p className="text-slate-400 text-xs mt-1">{lang === 'fa' ? 'مشاهده و معامله دارایی‌های توکنایز شده شما' : 'Manage and trade your tokenized assets'}</p>
                </div>

                {/* Interactive Performance Chart of the Portfolio */}
                <div className="w-full">
                  <YieldChart 
                    theme={theme} 
                    lang={lang} 
                    isPortfolioMode={true} 
                    isLoggedIn={isLoggedIn} 
                    onLoginClick={() => { setAuthMode('signIn'); setIsAuthModalOpen(true); }}
                    myPortfolio={myPortfolio}
                  />
                </div>

                {/* Portfolio Value Summary Header Card */}
                <div className={`p-6 rounded-3xl border shadow-xl flex flex-col md:flex-row justify-around gap-6 text-center ${
                  theme === 'dark' ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
                }`}>
                  <div>
                    <p className="text-slate-400 text-xs font-semibold">{t.totalBalance}</p>
                    <h2 className={`text-3xl font-extrabold mt-1 ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
                      {totalBalanceCalculated.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USDT
                    </h2>
                    <p className="text-[10px] text-slate-500 mt-1">
                      {currentUser.usdtBalance.toLocaleString()} USDT {lang === 'fa' ? '(نقد)' : '(Free USDT)'} + {totalSharesValue.toLocaleString()} USDT {lang === 'fa' ? '(سرمایه‌گذاری)' : '(Assets)'}
                    </p>
                  </div>
                  <div className="hidden md:block w-px bg-slate-800 my-2"></div>
                  <div>
                    <p className="text-slate-400 text-xs font-semibold">{t.totalPnl}</p>
                    <h2 className={`text-3xl font-extrabold mt-1 flex items-center justify-center gap-1 ${
                      totalPnLCalculated >= 0 ? 'text-emerald-500' : 'text-rose-500'
                    }`}>
                      {totalPnLCalculated >= 0 ? <ArrowUpRight size={24} /> : <ArrowDownRight size={24} />}
                      <span>{totalPnLCalculated >= 0 ? '+' : ''}{totalPnLCalculated.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USDT</span>
                    </h2>
                    <p className={`text-xs font-bold ${totalPnLCalculated >= 0 ? 'text-emerald-500' : 'text-rose-500'}`}>
                      {totalPnLCalculated >= 0 ? '+' : ''}{totalPnLPctCalculated.toFixed(2)}% ({t.recentMonth})
                    </p>
                  </div>
                </div>

                {/* Grid of Portfolio Cards */}
                {myPortfolio.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {myPortfolio.map(item => {
                      const asset = INITIAL_ASSETS.find(a => a.id === item.assetId);
                      if (!asset) return null;

                      const currentVal = item.shares * asset.price;
                      const costVal = item.shares * item.avgPrice;
                      const itemPnL = currentVal - costVal;
                      const itemPnLPct = costVal !== 0 ? (itemPnL / costVal) * 100 : 0;

                      return (
                        <div 
                          key={item.assetId}
                          className={`rounded-3xl border p-5 shadow-sm space-y-4 ${
                            theme === 'dark' ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
                          }`}
                        >
                          <div className="flex justify-between items-center">
                            <div>
                              <span className="text-xs font-bold text-blue-500 uppercase font-mono">#{asset.id}</span>
                              <h3 className={`text-base font-bold mt-0.5 ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
                                {lang === 'fa' ? asset.faName : asset.enName}
                              </h3>
                            </div>
                            <img 
                              src={`https://flagcdn.com/24x18/${asset.flag}.png`} 
                              alt={asset.flag}
                              className="rounded shadow-sm"
                              referrerPolicy="no-referrer"
                            />
                          </div>

                          <div className={`p-4 rounded-xl space-y-2 text-xs font-semibold ${
                            theme === 'dark' ? 'bg-slate-950/60' : 'bg-slate-50'
                          }`}>
                            <div className="flex justify-between">
                              <span className="text-slate-400">{lang === 'fa' ? 'تعداد دارایی:' : 'Amount Owned:'}</span>
                              <span className={theme === 'dark' ? 'text-white' : 'text-slate-900'}>
                                {item.shares.toLocaleString()} {lang === 'fa' ? 'سهم' : 'Shares'}
                              </span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-slate-400">{t.avgCost}</span>
                              <span className={theme === 'dark' ? 'text-white' : 'text-slate-900'}>{item.avgPrice} USDT</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-slate-400">{t.currentPrice}</span>
                              <span className={theme === 'dark' ? 'text-white' : 'text-slate-900'}>{asset.price} USDT</span>
                            </div>
                          </div>

                          <div className="flex justify-between items-center pt-2">
                            <div>
                              <p className="text-[10px] text-slate-400 uppercase font-bold">{t.pnlLabel}</p>
                              <p className={`text-sm font-extrabold ${itemPnL >= 0 ? 'text-emerald-500' : 'text-rose-500'}`}>
                                {itemPnL >= 0 ? '+' : ''}{itemPnL.toFixed(2)} USDT ({itemPnL >= 0 ? '+' : ''}{itemPnLPct.toFixed(1)}%)
                              </p>
                            </div>

                            <div className="flex gap-2">
                              {/* Quick Buy More */}
                              <button 
                                onClick={() => {
                                  setSelectedAsset(asset);
                                  setBuyAmount('');
                                  setIsBuyModalOpen(true);
                                }}
                                className="px-3 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold transition-all"
                              >
                                {t.buy}
                              </button>
                              {/* Sell Assets */}
                              <button 
                                onClick={() => {
                                  setSelectedAsset(asset);
                                  setSellShares('');
                                  setIsSellModalOpen(true);
                                }}
                                className="px-3 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-bold transition-all"
                              >
                                {t.sell}
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className={`p-12 text-center rounded-2xl border ${
                    theme === 'dark' ? 'bg-slate-900/40 border-slate-800' : 'bg-slate-100 border-slate-200'
                  }`}>
                    <p className="text-slate-400 text-sm">{lang === 'fa' ? 'شما هیچ دارایی خریداری نکرده‌اید.' : 'Your portfolio is currently empty.'}</p>
                    <button 
                      onClick={() => setCurrentTab('market')}
                      className="mt-4 px-6 py-2.5 bg-blue-600 text-white font-bold text-xs rounded-xl"
                    >
                      {lang === 'fa' ? 'مشاهده و خرید دارایی‌ها' : 'Explore Assets Market'}
                    </button>
                  </div>
                )}
              </section>
            )}

            {/* View 3: Deposit / Withdraw Staking */}
            {currentTab === 'wallet' && (
              <section className="space-y-6">
                <div>
                  <h1 className="text-2xl font-extrabold tracking-tight">{t.wallet}</h1>
                  <p className="text-slate-400 text-xs mt-1">{lang === 'fa' ? 'شارژ حساب تتر یا برداشت سریع' : 'Deposit and withdraw USDT securely'}</p>
                </div>

                <div className={`rounded-3xl border p-6 shadow-sm space-y-6 max-w-xl mx-auto ${
                  theme === 'dark' ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
                }`}>
                  {/* Tabs */}
                  <div className="flex border-b border-slate-800">
                    <button 
                      onClick={() => setWalletTab('deposit')}
                      className={`flex-1 py-3 text-sm font-bold text-center border-b-2 transition-all ${
                        walletTab === 'deposit' ? 'border-blue-500 text-blue-500 font-extrabold' : 'border-transparent text-slate-400'
                      }`}
                    >
                      {t.depositUsdt}
                    </button>
                    <button 
                      onClick={() => setWalletTab('withdraw')}
                      className={`flex-1 py-3 text-sm font-bold text-center border-b-2 transition-all ${
                        walletTab === 'withdraw' ? 'border-blue-500 text-blue-500 font-extrabold' : 'border-transparent text-slate-400'
                      }`}
                    >
                      {t.withdrawUsdt}
                    </button>
                  </div>

                  {/* Info Warning Banner */}
                  <div className={`p-4 rounded-xl flex gap-3 text-xs leading-relaxed border ${
                    theme === 'dark' ? 'bg-amber-950/20 border-amber-500/30 text-amber-300' : 'bg-amber-50 border-amber-200 text-amber-800'
                  }`}>
                    <Info size={16} className="shrink-0 text-amber-500" />
                    <span>{t.transactionWarning}</span>
                  </div>

                  {/* Network Selector */}
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-400 uppercase">{t.selectNetwork}</label>
                    <div className="grid grid-cols-3 gap-2">
                      {['trc20', 'erc20', 'bep20'].map((net) => (
                        <button
                          key={net}
                          onClick={() => setDepositNetwork(net as any)}
                          className={`py-2.5 rounded-xl text-xs font-bold transition-all border ${
                            depositNetwork === net
                              ? 'bg-blue-600 text-white border-blue-500'
                              : theme === 'dark'
                                ? 'bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800'
                                : 'bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200'
                          }`}
                        >
                          {net === 'trc20' && 'TRC20'}
                          {net === 'erc20' && 'ERC20'}
                          {net === 'bep20' && 'BEP20 (BSC)'}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Deposit View */}
                  {walletTab === 'deposit' && (
                    <form onSubmit={handleDepositSubmit} className="space-y-4">
                      {/* Live Deposit Address Box */}
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-400 uppercase">{t.depositAddress}</label>
                        <div className={`p-4 rounded-xl border text-center break-all font-mono text-sm relative group ${
                          theme === 'dark' ? 'bg-slate-950 border-slate-800 text-white' : 'bg-slate-50 border-slate-200 text-slate-800'
                        }`}>
                          <span>
                            {depositNetwork === 'trc20' && 'TUtwXkXYZ123abcTRC20dummyAddressDepositActive'}
                            {depositNetwork === 'erc20' && '0x123ERC20SecureAddressForAssetChainRWAStore'}
                            {depositNetwork === 'bep20' && '0x789BEP20SmartChainDepositSecuredEngine'}
                          </span>
                        </div>
                      </div>

                      {/* TxID hash Input */}
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-400 uppercase">{t.txidLabel}</label>
                        <input 
                          type="text" 
                          value={depositTxid}
                          onChange={(e) => setDepositTxid(e.target.value)}
                          placeholder={t.txidPlaceholder}
                          className={`w-full p-3 rounded-xl border focus:outline-none focus:border-blue-500 text-sm ${
                            theme === 'dark' ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-200'
                          }`}
                        />
                      </div>

                      <button 
                        type="submit"
                        className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white font-extrabold text-xs rounded-xl transition-all mt-4"
                      >
                        {t.submitDeposit}
                      </button>
                    </form>
                  )}

                  {/* Withdraw View */}
                  {walletTab === 'withdraw' && (
                    <form onSubmit={handleWithdrawSubmit} className="space-y-4">
                      {/* Destination address */}
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-400 uppercase">{t.destinationAddress}</label>
                        <input 
                          type="text" 
                          value={withdrawAddress}
                          onChange={(e) => setWithdrawAddress(e.target.value)}
                          placeholder={t.destinationPlaceholder}
                          className={`w-full p-3 rounded-xl border focus:outline-none focus:border-blue-500 text-sm ${
                            theme === 'dark' ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-200'
                          }`}
                        />
                      </div>

                      {/* Withdraw amount */}
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-400 uppercase">{t.amountUsdt}</label>
                        <input 
                          type="number" 
                          value={withdrawAmount}
                          onChange={(e) => setWithdrawAmount(e.target.value)}
                          placeholder={t.minAmount}
                          className={`w-full p-3 rounded-xl border focus:outline-none focus:border-blue-500 text-sm ${
                            theme === 'dark' ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-200'
                          }`}
                        />
                      </div>

                      <button 
                        type="submit"
                        className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white font-extrabold text-xs rounded-xl transition-all mt-4"
                      >
                        {t.requestWithdraw}
                      </button>
                    </form>
                  )}

                </div>
              </section>
            )}

            {/* View 4: Transaction History Table */}
            {currentTab === 'history' && (
              <section className="space-y-6">
                <div>
                  <h1 className="text-2xl font-extrabold tracking-tight">{t.transactionHistory}</h1>
                  <p className="text-slate-400 text-xs mt-1">{lang === 'fa' ? 'سوابق واریز، برداشت و معاملات گذشته شما' : 'History of your deposits, withdrawals, and trades'}</p>
                </div>

                <div className={`rounded-3xl border overflow-hidden shadow-sm ${
                  theme === 'dark' ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
                }`}>
                  <div className="overflow-x-auto">
                    <table className="w-full border-collapse text-start">
                      <thead>
                        <tr className={`border-b text-xs font-bold uppercase text-slate-400 text-start ${
                          theme === 'dark' ? 'border-slate-800 bg-slate-950/40' : 'border-slate-200 bg-slate-50'
                        }`}>
                          <th className="p-4 text-start">{t.thType}</th>
                          <th className="p-4 text-center">{t.thAmount}</th>
                          <th className="p-4 text-center">{t.thDate}</th>
                          <th className="p-4 text-end">{t.thStatus}</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800 text-xs">
                        {transactions.map(tx => (
                          <tr 
                            key={tx.id}
                            className={`transition-colors hover:bg-slate-800/10 ${
                              theme === 'dark' ? 'hover:bg-slate-800/20' : 'hover:bg-slate-100/50'
                            }`}
                          >
                            <td className="p-4 font-semibold">
                              <span className="capitalize">{lang === 'fa' ? t['hist_' + tx.type] : tx.type}</span>
                              <span className="text-[10px] text-slate-400 font-mono ms-2">({tx.asset})</span>
                            </td>
                            <td className="p-4 text-center font-mono font-bold" dir="ltr">
                              {tx.amount}
                            </td>
                            <td className="p-4 text-center text-slate-400 font-mono">
                              {tx.date}
                            </td>
                            <td className="p-4 text-end">
                              <span className={`px-2.5 py-1 rounded-md text-[10px] font-bold ${
                                tx.status === 'completed'
                                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                                  : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                              }`}>
                                {lang === 'fa' ? t['stat_' + tx.status] : tx.status}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </section>
            )}

            {/* View 5: Support Tickets */}
            {currentTab === 'support' && (
              <section className="space-y-6">
                <div>
                  <h1 className="text-2xl font-extrabold tracking-tight">{t.supportCenter}</h1>
                  <p className="text-slate-400 text-xs mt-1">{lang === 'fa' ? 'پاسخگویی تیکت‌های شما در کمتر از ۷۲ ساعت' : 'Get in touch with support agents'}</p>
                </div>

                <div className={`rounded-3xl border p-6 shadow-sm max-w-xl mx-auto space-y-4 ${
                  theme === 'dark' ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
                }`}>
                  <form onSubmit={handleSupportSubmit} className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-400 uppercase">{t.describeIssue}</label>
                      <textarea
                        rows={5}
                        value={supportText}
                        onChange={(e) => setSupportText(e.target.value)}
                        placeholder={t.howCanHelp}
                        className={`w-full p-3 rounded-xl border focus:outline-none focus:border-blue-500 text-sm ${
                          theme === 'dark' ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-200'
                        }`}
                        required
                      ></textarea>
                    </div>

                    <button
                      type="submit"
                      className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white font-extrabold text-xs rounded-xl transition-all"
                    >
                      {t.submitTicket}
                    </button>
                  </form>
                </div>
              </section>
            )}

            {/* View 6: About Us */}
            {currentTab === 'about' && (
              <section className="space-y-6">
                <div>
                  <h1 className="text-2xl font-extrabold tracking-tight">
                    {lang === 'fa' ? 'درباره اسِت‌چین' : 'About AssetChain'}
                  </h1>
                  <p className="text-slate-400 text-xs mt-1">
                    {lang === 'fa' ? 'نسل بعدی مالکیت دارایی‌های واقعی روی زنجیره' : 'The next generation of real-world asset ownership'}
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className={`p-6 rounded-3xl border shadow-sm space-y-3 ${
                    theme === 'dark' ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
                  }`}>
                    <div className="w-10 h-10 bg-blue-600/10 text-blue-500 rounded-xl flex items-center justify-center font-bold">
                      <ShieldCheck size={20} />
                    </div>
                    <h3 className={`text-base font-bold ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
                      {lang === 'fa' ? '۱۰۰٪ پشتوانه فیزیکی' : '100% Physical Custody'}
                    </h3>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      {lang === 'fa' 
                        ? 'تمامی توکن‌ها دارای پشتوانه شمش‌های طلا با عیار استاندارد و اسناد رسمی املاک ثبت شده در سوئیس و امارات هستند.'
                        : 'Every token is fully backed by certified gold bullion and legally registered properties in Switzerland & UAE.'}
                    </p>
                  </div>

                  <div className={`p-6 rounded-3xl border shadow-sm space-y-3 ${
                    theme === 'dark' ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
                  }`}>
                    <div className="w-10 h-10 bg-emerald-600/10 text-emerald-500 rounded-xl flex items-center justify-center font-bold">
                      <CheckCircle size={20} />
                    </div>
                    <h3 className={`text-base font-bold ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
                      {lang === 'fa' ? 'حساب‌رسی و شفافیت آنی' : 'Audited Proof of Reserves'}
                    </h3>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      {lang === 'fa' 
                        ? 'موسسه بین‌المللی SGS به عنوان حسابرس مستقل، موجودی فیزیکی خزانه‌ها را به صورت دوره‌ای تایید و گزارش می‌کند.'
                        : 'Independent global auditor SGS performs regular reserve verifications, matching physical assets with on-chain supply.'}
                    </p>
                  </div>

                  <div className={`p-6 rounded-3xl border shadow-sm space-y-3 ${
                    theme === 'dark' ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
                  }`}>
                    <div className="w-10 h-10 bg-purple-600/10 text-purple-500 rounded-xl flex items-center justify-center font-bold">
                      <Coins size={20} />
                    </div>
                    <h3 className={`text-base font-bold ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
                      {lang === 'fa' ? 'سرمایه‌گذاری خرد شده' : 'Fractionalized & Inclusive'}
                    </h3>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      {lang === 'fa' 
                        ? 'ما موانع سرمایه‌گذاری را حذف کرده‌ایم تا هر شخص بتواند با حداقل ۱ تتر، مالک سهم‌های ارزشمند در کلاس‌های دارایی لوکس شود.'
                        : 'We bypass high-capital entry limits, letting anyone buy fractions of elite physical assets starting with only 1 USDT.'}
                    </p>
                  </div>
                </div>

                <div className={`p-6 rounded-3xl border space-y-4 ${
                  theme === 'dark' ? 'bg-slate-900/40 border-slate-800' : 'bg-slate-100/50 border-slate-200'
                }`}>
                  <h3 className={`text-lg font-bold ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
                    {lang === 'fa' ? 'ماموریت اسِت‌چین' : 'The AssetChain Mission'}
                  </h3>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    {lang === 'fa'
                      ? 'هدف ما ایجاد بستری امن و عادلانه برای دسترسی همگانی به دارایی‌های باثبات جهانی است. ما با ادغام فناوری پیشرفته بلاکچین و قوانین شفاف مالی، بستری ایجاد کرده‌ایم تا نقدینگی و امنیت در بالاترین سطح ممکن در اختیار سرمایه‌گذاران خرد قرار گیرد.'
                      : 'Our mission is to democratize high-yield, secure investment classes. By combining state-of-the-art decentralized ledgers with compliant legal trust frameworks, we provide retail and institutional investors alike with unparalleled liquidity and audited physical backing.'}
                  </p>
                </div>
              </section>
            )}

            {/* View 7: Contact Us */}
            {currentTab === 'contact' && (
              <section className="space-y-6">
                <div>
                  <h1 className="text-2xl font-extrabold tracking-tight">
                    {lang === 'fa' ? 'ارتباط با ما' : 'Contact Us'}
                  </h1>
                  <p className="text-slate-400 text-xs mt-1">
                    {lang === 'fa' ? 'پاسخگویی سریع و پشتیبانی ۲۴ ساعته در تمامی روزهای هفته' : '24/7 global coverage and secure ticket submission'}
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Contact Form */}
                  <div className={`p-6 rounded-3xl border shadow-sm space-y-4 ${
                    theme === 'dark' ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
                  }`}>
                    <h3 className={`text-base font-bold ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
                      {lang === 'fa' ? 'ارسال پیام مستقیم' : 'Send a message'}
                    </h3>
                    <form onSubmit={handleSupportSubmit} className="space-y-4">
                      <div className="space-y-1">
                        <label className="text-xs font-semibold text-slate-400">{lang === 'fa' ? 'موضوع پیام' : 'Subject'}</label>
                        <input 
                          type="text" 
                          placeholder={lang === 'fa' ? 'مثال: سوال در مورد واریز تتر' : 'e.g. Deposit validation question'}
                          className={`w-full p-3 rounded-xl border focus:outline-none focus:border-blue-500 text-xs ${
                            theme === 'dark' ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-200'
                          }`}
                          required
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-xs font-semibold text-slate-400">{t.describeIssue}</label>
                        <textarea
                          rows={4}
                          value={supportText}
                          onChange={(e) => setSupportText(e.target.value)}
                          placeholder={t.howCanHelp}
                          className={`w-full p-3 rounded-xl border focus:outline-none focus:border-blue-500 text-xs ${
                            theme === 'dark' ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-200'
                          }`}
                          required
                        ></textarea>
                      </div>

                      <button
                        type="submit"
                        className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white font-extrabold text-xs rounded-xl transition-all cursor-pointer"
                      >
                        {lang === 'fa' ? 'ثبت و ارسال پیام' : 'Send Message'}
                      </button>
                    </form>
                  </div>

                  {/* Office Info & coordinates */}
                  <div className="space-y-6">
                    <div className={`p-6 rounded-3xl border shadow-sm space-y-4 ${
                      theme === 'dark' ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
                    }`}>
                      <h3 className={`text-base font-bold ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
                        {lang === 'fa' ? 'دفاتر بین‌المللی اسِت‌چین' : 'Global Registered Offices'}
                      </h3>
                      
                      <div className="space-y-4 text-xs font-medium">
                        <div className="flex gap-3 items-start">
                          <MapPin size={16} className="text-blue-500 shrink-0 mt-0.5" />
                          <div>
                            <p className={theme === 'dark' ? 'text-slate-200 font-bold' : 'text-slate-800 font-bold'}>
                              {lang === 'fa' ? 'دفتر دبی (امارات متحده عربی)' : 'Dubai Corporate HQ (UAE)'}
                            </p>
                            <p className="text-slate-400 mt-0.5">
                              {lang === 'fa' ? 'برج خلیفه، طبقه ۴۲، دبی، امارات متحده عربی' : 'Burj Khalifa, Floor 42, Downtown Dubai, UAE'}
                            </p>
                          </div>
                        </div>

                        <div className="flex gap-3 items-start">
                          <MapPin size={16} className="text-blue-500 shrink-0 mt-0.5" />
                          <div>
                            <p className={theme === 'dark' ? 'text-slate-200 font-bold' : 'text-slate-800 font-bold'}>
                              {lang === 'fa' ? 'دفتر سوئیس (خزانه‌داری)' : 'Zurich Vault Registry (Switzerland)'}
                            </p>
                            <p className="text-slate-400 mt-0.5">
                              {lang === 'fa' ? 'خیابان باهنوف، پلاک ۱۸، زوریخ، سوئیس' : 'Bahnhofstrasse 18, 8001 Zurich, Switzerland'}
                            </p>
                          </div>
                        </div>

                        <div className="flex gap-3 items-start">
                          <Clock size={16} className="text-emerald-500 shrink-0 mt-0.5" />
                          <div>
                            <p className={theme === 'dark' ? 'text-slate-200 font-bold' : 'text-slate-800 font-bold'}>
                              {lang === 'fa' ? 'ساعات کاری ناظران فیزیکی' : 'Physical Custody Audit Hours'}
                            </p>
                            <p className="text-slate-400 mt-0.5">
                              {lang === 'fa' ? 'شنبه تا چهارشنبه - ۰۹:۰۰ الی ۱۷:۰۰ به وقت اروپای مرکزی' : 'Mon - Fri, 09:00 - 17:00 CET'}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className={`p-6 rounded-3xl border shadow-sm space-y-2 text-xs font-semibold ${
                      theme === 'dark' ? 'bg-slate-900/30 border-slate-800/60' : 'bg-slate-100/60 border-slate-200'
                    }`}>
                      <p className="text-slate-400">{lang === 'fa' ? 'آدرس پست الکترونیکی:' : 'Corporate Support Email:'}</p>
                      <p className="text-blue-500 font-bold font-mono">support@assetchain.app</p>
                      <p className="text-slate-400 mt-2">{lang === 'fa' ? 'پشتیبانی برخط تلگرام:' : 'Direct Telegram Support Channel:'}</p>
                      <p className="text-blue-500 font-bold font-mono">@AssetChain_Support</p>
                    </div>
                  </div>
                </div>
              </section>
            )}

          </div>

          {/* Right Column / Sidebar Drawer (Aesthetic RWA stats, referral cards, etc) */}
          <aside className="lg:col-span-4 space-y-6">
            
            {/* Wallet Quick Balance Card */}
            {isLoggedIn && (
              <div className={`rounded-3xl border p-6 shadow-xl relative overflow-hidden ${
                theme === 'dark' ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
              }`}>
                {/* Visual decoration */}
                <div className="absolute top-0 right-0 w-32 h-32 bg-blue-600/5 rounded-full blur-2xl"></div>
                
                <h3 className={`text-base font-bold mb-4 ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
                  {lang === 'fa' ? 'حساب کاربری شما' : 'Your Wallet Account'}
                </h3>
                
                <div className="space-y-4">
                  <div className={`p-4 rounded-2xl ${theme === 'dark' ? 'bg-slate-950/60' : 'bg-slate-50'}`}>
                    <p className="text-[10px] text-slate-400 font-bold uppercase">{lang === 'fa' ? 'موجودی تتر آزاد (نقد):' : 'Available USDT Balance:'}</p>
                    <p className="text-2xl font-black text-blue-500 mt-1">
                      {currentUser.usdtBalance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} <span className="text-sm font-semibold">USDT</span>
                    </p>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <button 
                      onClick={() => setCurrentTab('wallet')}
                      className={`py-2.5 rounded-xl text-xs font-bold text-center border cursor-pointer hover:scale-[1.01] transition-all ${
                        theme === 'dark' ? 'border-slate-800 hover:bg-slate-800 text-slate-200' : 'border-slate-200 hover:bg-slate-100 text-slate-800'
                      }`}
                    >
                      {t.depositUsdt}
                    </button>
                    <button 
                      onClick={() => setCurrentTab('portfolio')}
                      className="py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold text-center cursor-pointer hover:scale-[1.01] transition-all"
                    >
                      {t.portfolio}
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Staking APY Referral Invite Card (gorgeous visual highlight from Sleek Interface) */}
            <div className="bg-gradient-to-br from-blue-600 to-indigo-700 rounded-3xl p-6 relative overflow-hidden text-white shadow-xl">
              <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-white/10 rounded-full"></div>
              <div className="absolute -top-10 -left-10 w-24 h-24 bg-blue-400/20 rounded-full blur-xl"></div>
              
              <div className="relative z-10 space-y-4">
                <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center">
                  <Share2 size={20} />
                </div>
                <div>
                  <h3 className="text-lg font-bold leading-tight">{t.shareAndEarn}</h3>
                  <p className="text-blue-100 text-xs mt-1 opacity-80">{t.referralText}</p>
                </div>
                <button 
                  onClick={handleCopyCode}
                  className="w-full py-3 bg-white hover:bg-slate-50 text-blue-600 rounded-xl text-xs font-bold transition-all shadow-md flex items-center justify-center gap-1"
                >
                  {copiedCode ? <Check size={14} className="text-emerald-500" /> : null}
                  <span>{copiedCode ? t.copied : t.referralCode}</span>
                </button>
              </div>
            </div>

            {/* Quick Demo Credentials Info Card */}
            <div className={`rounded-3xl border p-5 space-y-3 ${
              theme === 'dark' ? 'bg-slate-900/20 border-slate-800/80' : 'bg-slate-100/50 border-slate-200'
            }`}>
              <div className="flex items-center gap-2">
                <Info size={14} className="text-blue-500" />
                <span className="text-xs font-bold">{t.demoAccount}</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                {t.demoTip}
              </p>
            </div>

          </aside>

        </div>
      </div>
      )}
      </div>

      {/* Auth Modal (Sign In / Sign Up) */}
      {isAuthModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/65 backdrop-blur-sm flex items-center justify-center p-4">
          <div className={`w-full max-w-md rounded-3xl border p-6 md:p-8 space-y-6 relative shadow-2xl transition-all ${
            theme === 'dark' ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
          }`}>
            {/* Close */}
            <button 
              onClick={() => setIsAuthModalOpen(false)} 
              className="absolute top-4 right-4 text-slate-400 hover:text-white"
            >
              <X size={18} />
            </button>

            <div>
              <h2 className="text-xl font-bold tracking-tight">
                {authMode === 'signIn' ? t.signIn : t.signUp}
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                {lang === 'fa' ? 'سرمایه‌گذاری روی دارایی‌های دنیای واقعی با امنیت بالا' : 'Access high-yield secured asset tokens'}
              </p>
            </div>

            {authError && (
              <div className="p-3 bg-rose-950/20 border border-rose-500/30 rounded-xl text-xs text-rose-400 font-semibold text-center">
                {authError}
              </div>
            )}

            <form onSubmit={handleAuthSubmit} className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-400 uppercase">{t.usernameOrEmail}</label>
                <input 
                  type="text" 
                  value={authUsername}
                  onChange={(e) => setAuthUsername(e.target.value)}
                  className={`w-full p-3 rounded-xl border focus:outline-none focus:border-blue-500 text-sm ${
                    theme === 'dark' ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-200'
                  }`}
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-400 uppercase">{t.password}</label>
                <input 
                  type="password" 
                  value={authPassword}
                  onChange={(e) => setAuthPassword(e.target.value)}
                  className={`w-full p-3 rounded-xl border focus:outline-none focus:border-blue-500 text-sm ${
                    theme === 'dark' ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-200'
                  }`}
                  required
                />
              </div>

              <button 
                type="submit"
                className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white font-extrabold text-sm rounded-xl transition-all shadow-md mt-2"
              >
                {authMode === 'signIn' ? t.signIn : t.signUp}
              </button>
            </form>

            <div className="text-center">
              <button 
                onClick={() => {
                  setAuthMode(authMode === 'signIn' ? 'signUp' : 'signIn');
                  setAuthError('');
                }}
                className="text-xs text-slate-400 hover:text-white underline cursor-pointer"
              >
                {authMode === 'signIn' ? t.noAccount : t.hasAccount}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Buy Order Confirmation Modal */}
      {isBuyModalOpen && selectedAsset && (
        <div className="fixed inset-0 z-50 bg-black/65 backdrop-blur-sm flex items-center justify-center p-4">
          <div className={`w-full max-w-md rounded-3xl border p-6 space-y-6 relative shadow-2xl ${
            theme === 'dark' ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
          }`}>
            <button 
              onClick={() => setIsBuyModalOpen(false)} 
              className="absolute top-4 right-4 text-slate-400 hover:text-white"
            >
              <X size={18} />
            </button>

            <div>
              <h2 className="text-lg font-bold tracking-tight">{t.confirmBuy}</h2>
              <p className="text-xs text-slate-400 mt-0.5">{lang === 'fa' ? 'سفارش خرید دارایی RWA' : 'Buy secured real-world token shares'}</p>
            </div>

            <div className={`p-4 rounded-xl flex items-center justify-between ${
              theme === 'dark' ? 'bg-slate-950/60' : 'bg-slate-50'
            }`}>
              <div>
                <span className="text-xs text-slate-400 font-bold uppercase font-mono">#{selectedAsset.id}</span>
                <p className="text-sm font-bold">{lang === 'fa' ? selectedAsset.faName : selectedAsset.enName}</p>
              </div>
              <div className="text-end">
                <span className="text-xs text-slate-400">{t.tokenPrice}</span>
                <p className="text-sm font-black text-blue-500">{selectedAsset.price} USDT</p>
              </div>
            </div>

            <form onSubmit={handleBuySubmit} className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-400 uppercase">{t.amountToInvest}</label>
                <div className="relative">
                  <input 
                    type="number" 
                    value={buyAmount}
                    onChange={(e) => setBuyAmount(e.target.value)}
                    placeholder="Enter USDT Amount"
                    className={`w-full p-3 pr-16 rounded-xl border focus:outline-none focus:border-blue-500 text-sm ${
                      theme === 'dark' ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-200'
                    }`}
                    required
                  />
                  <span className="absolute right-3 top-3 text-xs font-bold text-blue-500">
                    USDT
                  </span>
                </div>
                {currentUser && (
                  <p className="text-[10px] text-slate-400 mt-1">
                    {lang === 'fa' ? 'موجودی آزاد:' : 'Available Balance:'} {currentUser.usdtBalance.toLocaleString()} USDT
                  </p>
                )}
              </div>

              {/* Real-time Order Details Breakdown */}
              {(() => {
                const val = parseFloat(buyAmount) || 0;
                const fee = val * 0.001;
                const shares = Math.floor(val / selectedAsset.price) || 0;
                const total = val + fee;

                return (
                  <div className={`p-4 rounded-xl text-xs space-y-2 font-medium ${
                    theme === 'dark' ? 'bg-slate-950/40' : 'bg-slate-50'
                  }`}>
                    <div className="flex justify-between">
                      <span className="text-slate-400">{t.estShares}</span>
                      <span className={`font-bold ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>{shares.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">{t.fee}</span>
                      <span className={`font-bold ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>{fee.toFixed(2)} USDT</span>
                    </div>
                    <hr className="border-slate-800/80 my-2" />
                    <div className="flex justify-between text-sm font-extrabold">
                      <span className="text-slate-400">{t.totalToPay}</span>
                      <span className="text-blue-500">{total.toFixed(2)} USDT</span>
                    </div>
                  </div>
                );
              })()}

              <button 
                type="submit"
                className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white font-extrabold text-sm rounded-xl transition-all shadow-md mt-2"
              >
                {t.confirmBuy}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Sell Order Confirmation Modal */}
      {isSellModalOpen && selectedAsset && (
        <div className="fixed inset-0 z-50 bg-black/65 backdrop-blur-sm flex items-center justify-center p-4">
          <div className={`w-full max-w-md rounded-3xl border p-6 space-y-6 relative shadow-2xl ${
            theme === 'dark' ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
          }`}>
            <button 
              onClick={() => setIsSellModalOpen(false)} 
              className="absolute top-4 right-4 text-slate-400 hover:text-white"
            >
              <X size={18} />
            </button>

            <div>
              <h2 className="text-lg font-bold tracking-tight">{t.confirmSell}</h2>
              <p className="text-xs text-slate-400 mt-0.5">{lang === 'fa' ? 'سفارش فروش سهم دارایی RWA' : 'Liquidate asset tokens back to USDT'}</p>
            </div>

            <div className={`p-4 rounded-xl flex items-center justify-between ${
              theme === 'dark' ? 'bg-slate-950/60' : 'bg-slate-50'
            }`}>
              <div>
                <span className="text-xs text-slate-400 font-bold uppercase font-mono">#{selectedAsset.id}</span>
                <p className="text-sm font-bold">{lang === 'fa' ? selectedAsset.faName : selectedAsset.enName}</p>
              </div>
              <div className="text-end">
                <span className="text-xs text-slate-400">{t.tokenPrice}</span>
                <p className="text-sm font-black text-amber-500">{selectedAsset.price} USDT</p>
              </div>
            </div>

            <form onSubmit={handleSellSubmit} className="space-y-4">
              <div className="space-y-1">
                <div className="flex justify-between items-center">
                  <label className="text-xs font-bold text-slate-400 uppercase">{t.sharesToSell}</label>
                  <span className="text-[10px] text-slate-400 font-bold">
                    {t.ownedShares.replace('{num}', activeMaxShares.toLocaleString())}
                  </span>
                </div>
                <div className="relative">
                  <input 
                    type="number" 
                    value={sellShares}
                    onChange={(e) => setSellShares(e.target.value)}
                    placeholder="Enter Shares count"
                    className={`w-full p-3 pr-16 rounded-xl border focus:outline-none focus:border-blue-500 text-sm ${
                      theme === 'dark' ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-200'
                    }`}
                    required
                  />
                  <span className="absolute right-3 top-3 text-xs font-bold text-slate-500">
                    {lang === 'fa' ? 'سهم' : 'Shares'}
                  </span>
                </div>
              </div>

              {/* Real-time Sell details breakdown */}
              {(() => {
                const sharesCount = parseInt(sellShares) || 0;
                const gross = sharesCount * selectedAsset.price;
                const fee = gross * 0.001;
                const net = gross - fee;

                return (
                  <div className={`p-4 rounded-xl text-xs space-y-2 font-medium ${
                    theme === 'dark' ? 'bg-slate-950/40' : 'bg-slate-50'
                  }`}>
                    <div className="flex justify-between">
                      <span className="text-slate-400">{t.grossValue}</span>
                      <span className={`font-bold ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>{gross.toFixed(2)} USDT</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">{t.fee}</span>
                      <span className={`font-bold ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>{fee.toFixed(2)} USDT</span>
                    </div>
                    <hr className="border-slate-800/80 my-2" />
                    <div className="flex justify-between text-sm font-extrabold">
                      <span className="text-slate-400">{t.netReceive}</span>
                      <span className="text-emerald-500">{net.toFixed(2)} USDT</span>
                    </div>
                  </div>
                );
              })()}

              <button 
                type="submit"
                className="w-full py-3 bg-amber-600 hover:bg-amber-500 text-white font-extrabold text-sm rounded-xl transition-all shadow-md mt-2"
              >
                {t.confirmSell}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className={`border-t transition-colors duration-300 ${
        theme === 'dark' ? 'bg-slate-950 border-slate-900 text-slate-400' : 'bg-white border-slate-200 text-slate-500'
      }`}>
        {/* Main Footer Content */}
        <div className="max-w-7xl mx-auto px-4 md:px-8 py-16">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 md:gap-12">
            
            {/* Column 1: Brand & Identity */}
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center font-bold text-white shadow-lg shadow-blue-500/25">
                  <Coins size={16} />
                </div>
                <span className={`text-lg font-extrabold tracking-tight ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
                  {t.appName}
                </span>
              </div>
              <p className="text-xs leading-relaxed opacity-85">
                {lang === 'fa' 
                  ? 'سرمایه‌گذاری در دارایی‌های دنیای واقعی (RWA) با امنیت کامل و پشتوانه فیزیکی ۱۰۰ درصدی بر روی شبکه بلاکچین. دسترسی آسان به سودآوری جهانی.'
                  : 'Regulated, secured, and fully backed real-world asset (RWA) tokenization on-chain. Making global yields and institutional custody accessible to everyone.'}
              </p>
              
              {/* Market Status Feed */}
              <div className="space-y-2 pt-2">
                <div className={`p-3 rounded-2xl border text-[11px] font-bold flex items-center justify-between ${
                  theme === 'dark' ? 'bg-slate-900/40 border-slate-900/60' : 'bg-slate-50 border-slate-100'
                }`}>
                  <span className="flex items-center gap-1.5">
                    <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
                    <span>{t.marketStatus}</span>
                  </span>
                  <span className="text-blue-500 font-mono">{t.vol24h}</span>
                </div>
              </div>
            </div>

            {/* Column 2: RWA Marketplace Categories */}
            <div className="space-y-4">
              <h4 className={`text-xs font-black uppercase tracking-wider ${theme === 'dark' ? 'text-slate-200' : 'text-slate-900'}`}>
                {lang === 'fa' ? 'بازارهای سرمایه‌گذاری RWA' : 'RWA Market Sectors'}
              </h4>
              <ul className="space-y-2.5 text-xs">
                {[
                  { id: 'commodities', en: 'Gold & Commodities', fa: 'ذخایر شمش طلا' },
                  { id: 'real_estate', en: 'Luxury Real Estate', fa: 'املاک و مستغلات لوکس' },
                  { id: 'metals', en: 'High-Grade Metals', fa: 'فلزات و صنایع اساسی' },
                  { id: 'global', en: 'Global Blue-Chip Shares', fa: 'سهام و اوراق بهادار جهانی' },
                  { id: 'petro', en: 'Petrochemical Reserves', fa: 'پتروشیمی و صنایع نفتی' },
                ].map(cat => (
                  <li key={cat.id}>
                    <button 
                      onClick={() => {
                        setMarketFilter(cat.id);
                        setCurrentTab('market');
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      className="hover:text-blue-500 transition-colors flex items-center gap-1.5 cursor-pointer text-start"
                    >
                      <span className="opacity-40">#</span>
                      <span>{lang === 'fa' ? cat.fa : cat.en}</span>
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {/* Column 3: Navigation & Platform */}
            <div className="space-y-4">
              <h4 className={`text-xs font-black uppercase tracking-wider ${theme === 'dark' ? 'text-slate-200' : 'text-slate-900'}`}>
                {lang === 'fa' ? 'ناوبری و پلتفرم' : 'Platform Navigation'}
              </h4>
              <ul className="space-y-2.5 text-xs">
                {[
                  { tab: 'home', label: t.home },
                  { tab: 'market', label: t.assetsMarket },
                  { tab: 'portfolio', label: t.portfolio, authRequired: true },
                  { tab: 'wallet', label: t.wallet, authRequired: true },
                  { tab: 'history', label: t.history, authRequired: true },
                  { tab: 'about', label: t.aboutUs },
                  { tab: 'contact', label: t.contactUs },
                ].map(item => {
                  if (item.authRequired && !isLoggedIn) return null;
                  return (
                    <li key={item.tab}>
                      <button 
                        onClick={() => {
                          setCurrentTab(item.tab as any);
                          window.scrollTo({ top: 0, behavior: 'smooth' });
                        }}
                        className="hover:text-blue-500 transition-colors cursor-pointer text-start"
                      >
                        {item.label}
                      </button>
                    </li>
                  );
                })}
              </ul>
            </div>

            {/* Column 4: Location & Support Details */}
            <div className="space-y-4">
              <h4 className={`text-xs font-black uppercase tracking-wider ${theme === 'dark' ? 'text-slate-200' : 'text-slate-900'}`}>
                {lang === 'fa' ? 'اطلاعات پشتیبانی و دفتر مرکزی' : 'Support & Legal Presence'}
              </h4>
              <div className="space-y-3.5 text-xs">
                <div className="flex items-start gap-2.5">
                  <MapPin size={16} className="text-blue-500 shrink-0 mt-0.5" />
                  <p className="leading-relaxed">
                    {lang === 'fa' 
                      ? 'دفتر مرکزی: دبی، امارات، منطقه سیلیکون اوآسیس، برج فناوری' 
                      : 'HQ Presence: Silicon Oasis Tech Tower, Dubai, United Arab Emirates'}
                  </p>
                </div>
                <div className="flex items-start gap-2.5">
                  <ShieldCheck size={16} className="text-blue-500 shrink-0 mt-0.5" />
                  <p className="leading-relaxed">
                    {lang === 'fa' 
                      ? 'امانت‌داری فیزیکی: زوریخ، سوئیس، صندوق امانات بانک کانتونال' 
                      : 'Physical Asset Custody: Zurich Canton Trust Vaults, Switzerland'}
                  </p>
                </div>
                <div className="flex items-center gap-2.5">
                  <MessageSquare size={16} className="text-blue-500 shrink-0" />
                  <p className="font-mono font-bold hover:text-blue-500 transition-colors cursor-pointer">
                    support@assetchain.app
                  </p>
                </div>
                <div className="flex items-center gap-2.5">
                  <Globe size={16} className="text-blue-500 shrink-0" />
                  <p className="font-mono font-bold hover:text-blue-500 transition-colors cursor-pointer">
                    @AssetChain_Support
                  </p>
                </div>
              </div>
            </div>

          </div>

          {/* Separation Border */}
          <hr className={`my-12 ${theme === 'dark' ? 'border-slate-900' : 'border-slate-100'}`} />

          {/* Legal Disclaimer Box */}
          <div className={`p-5 rounded-2xl border text-[11px] leading-relaxed mb-12 ${
            theme === 'dark' 
              ? 'bg-slate-900/20 border-slate-900/60 text-slate-500' 
              : 'bg-slate-50 border-slate-100 text-slate-400'
          }`}>
            <p className="font-bold mb-1.5 uppercase text-[10px] text-blue-500 tracking-wider">
              {lang === 'fa' ? 'سلب مسئولیت و شفافیت قانونی' : 'REGULATORY NOTICE & RISK DISCLOSURE'}
            </p>
            <p>
              {lang === 'fa'
                ? 'سلب مسئولیت: سرمایه‌گذاری روی دارایی‌های دنیای واقعی (RWA) شامل ریسک نوسان قیمت بازار می‌باشد. هر توکن اسِت‌چین نماینده سهم مشخصی از دارایی‌های فیزیکی تحت پشتوانه کامل ۱:۱ بوده که دارای گزارش حسابرسی رسمی و تاییدیه مالکیت ثبتی است. دارایی‌های فیزیکی در خزانه‌های امن سوئیس و تحت قوانین نظارتی ذخیره‌سازی نگهداری می‌شوند. این پلتفرم صرفاً بستر معامله دارایی‌ها به صورت توکنایز شده بوده و خدمات مشاوره مالی ارایه نمی‌دهد.'
                : 'Disclaimer: Real-World Asset (RWA) fractional token investments carry market risks due to commodity and asset price fluctuations. Every AssetChain token is physically backed 1:1, audited by regulated third-party custodians, and secured in Swiss high-security Canton vaults. Fractionalized shares represent actual beneficial interest. Past performance of asset growth yields does not guarantee future results. This platform serves as a digital transaction medium and does not provide financial advice.'}
            </p>
          </div>

          {/* Bottom Row */}
          <div className="flex flex-col md:flex-row items-center justify-between gap-6 text-[11px]">
            <div className="flex items-center gap-2 font-bold">
              <span>© 2026 {t.appName}. {t.rightsReserved}</span>
            </div>

            {/* Quick Links / Status indicators */}
            <div className="flex flex-wrap items-center gap-4 md:gap-6">
              <a href="#" className="hover:text-blue-500 transition-colors">{t.termsAndConditions}</a>
              <span className="opacity-40">•</span>
              <button onClick={() => { setCurrentTab('support'); window.scrollTo({ top: 0, behavior: 'smooth' }); }} className="hover:text-blue-500 transition-colors cursor-pointer">
                {t.onlineSupport}
              </button>
              <span className="opacity-40">•</span>
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
                <span className="text-emerald-500 font-bold">{lang === 'fa' ? 'شبکه اصلی فعال' : 'Mainnet Connected'}</span>
              </div>
            </div>
          </div>

        </div>
      </footer>

    </div>
  );
}
